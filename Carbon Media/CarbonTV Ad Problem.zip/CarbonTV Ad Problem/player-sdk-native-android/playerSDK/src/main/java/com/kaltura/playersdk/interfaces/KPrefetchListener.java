package com.kaltura.playersdk.interfaces;

/**
 * Created by gilad.nadav on 21/10/2016.
 */

public interface KPrefetchListener {
    void onPrefetchFinished();
}
