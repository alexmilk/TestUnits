package com.kaltura.playersdk;

/**
 * Created by itayi on 2/19/15.
 */
public interface KLiveStream {
    public void switchToLive();
}
