package com.kaltura.playersdk.actionHandlers.ShareStrategies;

import android.app.Activity;

import org.json.JSONObject;

/**
 * Created by nissopa on 2/24/15.
 */
public class FacebookShareStrategy extends WebShareStrategy {


    @Override
    public void share(JSONObject shareParams, Activity activity) {
        super.share(shareParams, activity);
    }
}


