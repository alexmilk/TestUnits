package com.kaltura.playersdk.tracks;

public enum TrackType {
	VIDEO,
	AUDIO,
	TEXT
}
