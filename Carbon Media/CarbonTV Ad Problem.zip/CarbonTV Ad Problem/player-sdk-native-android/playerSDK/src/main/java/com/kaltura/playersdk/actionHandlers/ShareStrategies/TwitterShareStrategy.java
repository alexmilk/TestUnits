package com.kaltura.playersdk.actionHandlers.ShareStrategies;

/**
 * Created by nissopa on 2/26/15.
 */
public class TwitterShareStrategy extends WebShareStrategy {

}
